﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace RACING
{

    interface Iauto
    {     
       void Run();
       bool Finish();
    }

    class SportCar : Iauto
    {
        string Number;
        int Speed;
        int Point;

        public SportCar(string num)
        {
            Number = num;
            Random rnd = new Random();
            Speed = rnd.Next(10, 20);
            Point = 0;
        }

        public void Run()
        {
            Point += Speed;
            Console.WriteLine($"Спортивный автомобиль под номером {Number} находится в {Point} метрах от старта");
        }

        public bool Finish()
        {
            if(Point < 100)
            {
                return false;
            }
            else
            {
                Console.WriteLine($"ПОЗДРАВЛЯЕМ СПОРТИВНЫЙ АВТОМОБИЛЬ ПОД НОМЕРОМ {Number} С ПОБЕДОЙ");
                return true;
            }
        }
    }



    class SimpleAuto : Iauto
    {
        string Number;
        int Speed;
        int Point;

        public SimpleAuto(string num)
        {
            Number = num;
            Random rnd = new Random();
            Speed = rnd.Next(5, 15);
            Point = 0;
        }

        public void Run()
        {
            Point += Speed;
            Console.WriteLine($"Автомобиль под номером {Number} находится в {Point} метрах от старта");
        }

        public bool Finish()
        {
            if (Point < 100)
            {
                return false;
            }
            else
            {
                Console.WriteLine($"ПОЗДРАВЛЯЕМ АВТОМОБИЛЬ ПОД НОМЕРОМ {Number} С ПОБЕДОЙ");
                return true;
            }
        }
    }




    class Track : Iauto
    {
        string Number;
        int Speed;
        int Point;

        public Track(string num)
        {
            Number = num;
            Random rnd = new Random();
            Speed = rnd.Next(5, 10);
            Point = 0;
        }

        public void Run()
        {
            Point += Speed;
            Console.WriteLine($"Грузовик под номером {Number} находится в {Point} метрах от старта");
        }

        public bool Finish()
        {
            if (Point < 100)
            {
                return false;
            }
            else
            {
                Console.WriteLine($"ПОЗДРАВЛЯЕМ ГРУЗОВИК ПОД НОМЕРОМ {Number} С ПОБЕДОЙ");
                return true;
            }
        }
    }




    class Program
    {
        static void Main(string[] args)
        {
            SportCar s_car = new SportCar("1");
            SimpleAuto car = new SimpleAuto("2");
            Track t_car = new Track("3");
            bool is_finish1;
            bool is_finish2;
            bool is_finish3;
            while (true)
            {
                s_car.Run();
                car.Run();
                t_car.Run();

                is_finish1 = s_car.Finish();
                is_finish2 = car.Finish();
                is_finish3 = t_car.Finish();

                if (is_finish1 == true || is_finish2 == true || is_finish3 == true)
                {
                   

                    break;
                }
                Console.WriteLine();
                
                Thread.Sleep(2000);
                
            }
        }
    }
}
